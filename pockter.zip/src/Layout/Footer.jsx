import React from "react";

const Footer = () => {
  return (
    <div className="footer_container">
      <div className="footer_md">
        <p>© Design and Developed by Smash Code 2021, All rights reserved</p>
      </div>
    </div>
  );
};

export default Footer;
